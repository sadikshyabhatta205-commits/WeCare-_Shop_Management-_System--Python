"""
read.py

This module handles reading the inventory from a product file.
"""

def read_inventory(filename="product.txt"):
    """Reads inventory data from the specified file and returns it as a list of dictionaries."""
    inventory = []
    try:
        with open(filename, "r") as file:
            for line in file:
                parts = line.split(',')
                if len(parts) == 5:
                    # Create a product dictionary from parts of the line
                    product = {
                        "name": parts[0],
                        "brand": parts[1],
                        "quantity": int(parts[2]),
                        "cost": float(parts[3]),
                        "origin": parts[4].replace('\n', '')  # Removes newline without using strip
                    }
                    inventory.append(product)
    except FileNotFoundError:
        print("Inventory file not found. Please ensure 'product.txt' exists.")
    return inventory
