"""
operation.py

This module handles all business operations like viewing, selling, and restocking products.
"""

from write import save_inventory, generate_invoice
from datetime import datetime

def display_products(inventory):
    """Displays all products with their current details."""
    print("\nProduct\tBrand\tQuantity\tSell Price\tOrigin")
    print("--------------------------------------------------------------")
    for item in inventory:
        # Calculate selling price as double the cost
        price = int(item["cost"] * 2)
        print(item["name"] + "\t" + item["brand"] + "\t" + str(item["quantity"]) + "\t\tRs " + str(price) + "\t" + item["origin"])

def sell_to_customer(inventory):
    """Handles selling products to a customer, generating invoice, and updating stock."""
    try:
        # Validate customer ID
        while True:
            customer_id = input("Enter customer ID (numbers only): ")
            if customer_id.isdigit():
                break
            else:
                print("Invalid ID. Please enter numbers only.")

        bill = "Customer ID: " + customer_id + "\nDate: " + str(datetime.now()) + "\nItems Sold:\n"
        total = 0

        # Process multiple product sales
        while True:
            product = input("Enter product to sell (or 'done' to finish): ")
            if product.lower() == "done":
                break

            found = False
            for item in inventory:
                if item["name"].lower() == product.lower():
                    found = True
                    qty = input("Enter quantity: ")
                    if qty.isnumeric():
                        qty = int(qty)
                        free = qty // 3  # Buy 3 Get 1 Free offer
                        total_qty = qty + free

                        if total_qty <= item["quantity"]:
                            item["quantity"] -= total_qty
                            price = int(item["cost"] * 2)
                            cost = price * qty
                            total += cost
                            bill += item["name"] + " (" + item["brand"] + ") - " + str(qty) + "+" + str(free) + " Free\tRs " + str(cost) + "\n"
                        else:
                            print("Not enough stock.")
                    else:
                        print("Invalid quantity. Enter a number.")
                    break
            if not found:
                print("Product not found.")

        bill += "\nTotal Amount: Rs " + str(total) + "\n"
        filename = generate_invoice(bill, "sell")
        print("\nInvoice saved as: " + filename)
        print("\n" + bill)
        save_inventory(inventory)
    except:
        print("An error occurred during selling.")

def purchase_from_vendor(inventory):
    """Handles restocking inventory and generating a vendor purchase note."""
    try:
        vendor = input("Enter vendor name: ")
        note = "Vendor: " + vendor + "\nDate: " + str(datetime.now()) + "\nItems Purchased:\n"
        total_cost = 0

        # Process multiple purchases
        while True:
            product = input("Enter product to purchase (or 'done' to finish): ")
            if product.lower() == "done":
                break

            found = False
            for item in inventory:
                if item["name"].lower() == product.lower():
                    found = True
                    qty = input("Enter quantity: ")
                    cost = input("Enter new cost (or press enter to keep old): ")

                    if qty.isnumeric():
                        qty = int(qty)
                        item["quantity"] += qty
                        if cost != "":
                            try:
                                item["cost"] = float(cost)
                            except:
                                print("Invalid cost. Keeping old cost.")
                        line_cost = qty * item["cost"]
                        total_cost += line_cost
                        note += item["name"] + " (" + item["brand"] + ") - " + str(qty) + " @ Rs " + str(item["cost"]) + " = Rs " + str(line_cost) + "\n"
                    else:
                        print("Quantity must be a number.")
                    break
            if not found:
                print("Product not found.")

        note += "\nTotal Purchase Cost: Rs " + str(total_cost) + "\n"
        filename = generate_invoice(note, "purchase")
        print("\nPurchase note saved as: " + filename)
        print("\n" + note)
        save_inventory(inventory)
    except:
        print("An error occurred during purchase from vendor.")
