"""
main.py

This is the main module that presents a menu-driven interface to the user.
"""

from read import read_inventory
from operation import display_products, sell_to_customer, purchase_from_vendor

def main():
    """Main function to display menu and handle user selection."""
    inventory = read_inventory()  # Load product inventory at start

    while True:
        # Menu display
        print("\n===== WeCare Beauty & Skin Care Shop Management =====")
        print("1. Display Available Products")
        print("2. Sell Product to Customer")
        print("3. Purchase Products from Vendor")
        print("4. Exit")

        choice = input("Enter your choice (1-4): ")

        # Call corresponding operation
        if choice == "1":
            display_products(inventory)
        elif choice == "2":
            sell_to_customer(inventory)
        elif choice == "3":
            purchase_from_vendor(inventory)
        elif choice == "4":
            print("Exiting... Thank you for using WeCare system!")
            break
        else:
            print("Invalid choice. Please select 1 to 4.")

# Run the main program
if __name__ == "__main__":
    main()
