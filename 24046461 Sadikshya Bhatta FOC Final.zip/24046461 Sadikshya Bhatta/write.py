"""
write.py

This module handles saving the inventory and generating invoice or purchase files.
"""

from datetime import datetime

def save_inventory(inventory, filename="product.txt"):
    """Saves the current inventory to the specified file."""
    try:
        with open(filename, "w") as file:
            for item in inventory:
                # Convert dictionary to comma-separated line
                line = item['name'] + "," + item['brand'] + "," + str(item['quantity']) + "," + str(item['cost']) + "," + item['origin'] + "\n"
                file.write(line)
    except:
        print("Error saving the inventory file.")

def generate_invoice(content, prefix):
    """Generates a uniquely named invoice or purchase file with given content."""
    filename = prefix + "_" + datetime.now().strftime("%Y%m%d_%H%M%S") + ".txt"
    try:
        with open(filename, "w") as file:
            file.write(content)
    except:
        print("Error writing invoice file.")
    return filename
